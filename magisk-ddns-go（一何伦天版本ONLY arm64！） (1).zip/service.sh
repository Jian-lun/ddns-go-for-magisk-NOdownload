#!/system/bin/sh

# 等待系统启动完成
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 5
done

# 延迟 60 秒等待网络稳定
sleep 60

# 设置日志和 PID 文件路径
LOG_FILE="/data/ddns-go.log"
PID_FILE="/data/ddns-go.pid"

# 清理旧日志
echo "===== $(date '+%Y-%m-%d %H:%M:%S') =====" > "$LOG_FILE"

# 检查并启动 ddns-go
start_ddnsgo() {
    if [ -f "$PID_FILE" ]; then
        PID=$(cat "$PID_FILE")
        if ps -p "$PID" > /dev/null; then
            echo "ddns-go is already running (PID: $PID)" >> "$LOG_FILE"
            return
        fi
    fi

    echo "Starting ddns-go..." >> "$LOG_FILE"
    /system/bin/ddns-go >> "$LOG_FILE" 2>&1 &
    echo $! > "$PID_FILE"
    echo "ddns-go started (PID: $!)" >> "$LOG_FILE"
}

# 首次启动
start_ddnsgo

# 每 5 分钟检查一次进程是否存活
while true; do
    if [ ! -f "$PID_FILE" ] || ! ps -p "$(cat "$PID_FILE")" > /dev/null; then
        echo "ddns-go crashed, restarting..." >> "$LOG_FILE"
        start_ddnsgo
    fi
    sleep 300  # 5 分钟检查一次
done